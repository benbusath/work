# -*- coding: utf-8 -*-
"""
This code takes in a list of 1940 pids and finds the arks/pids of their children.
We do this by going to a previous census where parents would be likely to share a 
household with their kids, and uses the ark-pid crosswalk to find the pids of the focus
people's children. We then use the pids to find both ancestry ids and 1940 census arks 
for the children.


Please note: 
    Children of a target person can only be found under the following conditions:
        1. Target person is the head or is married to a head of household in a previous census
        2. Target person is the parent of the head of household
        3. Target person has kids who share household with target person in a previous census.
    

Created on Wed Feb 13 20:15:40 2019

@author: Ben Busath
"""

import pandas as pd
from tqdm import tqdm
import time as time
k=1000
year='1910'

'''
*****FILTER DATA TO 1920 CENSUS*****

#pid_ark1920=pd.read_csv(r'R:\JoePriceResearch\record_linking\projects\social_security\data\target_pid_ark_1920.csv')
#ark1920=pid_ark1920.drop(columns=['pid'])
#del pid_ark1920

#index_ark1920=pd.read_stata(r'R:\JoePriceResearch\record_linking\data\census_compact\1920\int_ark1920.dta')
#index1920=index_ark1920[index_ark1920['ark1920'].isin(ark1920['ark1920'])]
#del index_ark1920, ark1920

#index1920=index1920.drop(columns=['ark1920'])

#index1920.to_csv(r'R:\JoePriceResearch\record_linking\projects\social_security\data\target_index_1920.csv',index=False)
'''

def get_elderly_index_list():
    '''
    Returns an index list from the preprocessed elderly index_ark crosswalk. 
    elderly_preproc must be ran first for this to work.
    '''
    global year
    int_ark=pd.read_csv(r'R:\JoePriceResearch\record_linking\projects\social_security\data\temp_int_ark.csv',usecols=['index{}'.format(year)])
    return int_ark['index{}'.format(year)].tolist()

def get_master_hhid_list(census):
    '''
    census: census dataframe. Should contain all elderly parents 
            and their kids for a specific year.
    
    Retrieves a list of all the unique household ids of the elderly focus group. 
    '''
    index_list=get_elderly_index_list()
    return census[census['index'].isin(index_list)]['household'].drop_duplicates().tolist()
    
def get_target_elderly():
    return pd.read_csv(r'R:\JoePriceResearch\record_linking\projects\social_security\data\temp_int_ark.csv')

def elderly_preproc():
    '''
    Preprocesses elderly data. 
        1. Drops target elderly pids that are missing from previous year pid-ark crosswalk.
        2. Finds previous-year census arks for target elderly pids
        3. Finds census indexes for target elderly pids.
        4. Saves this information into temporary csv file.
    '''
    global year
    elderly_pid_ark1940=pd.read_csv(r'R:\JoePriceResearch\record_linking\projects\social_security\data\elderly_pid_ark1940.csv')
    pids=pd.read_stata(r'R:\JoePriceResearch\record_linking\data\crosswalks\pid_ark{}.dta'.format(year))
    pids=pids[pids['pid'].isin(elderly_pid_ark1940['pid'])]
    
    anchor_col='ark'.format(year)
    if year=='1910':
        path=r'R\J:oePriceResearch\record_linking\data\census_compact\1910\int_ark1910.dta'
    
    
    int_ark=pd.read_stata(path)
    df=merge(pids,int_ark,anchor_col,anchor_col,drop=True)
    df.to_csv(r'R:\JoePriceResearch\record_linking\projects\social_security\data\temp_int_ark.csv')
    
def merge(df1,df2,left_on,right_on,drop=False):     
    '''
         df1: left dataframe to merge
         df2: right dataframe to merge
     left_on: column of left dataframe to merge on
    right_on: column of right dataframe to merge on
    
    Takes two dataframes and returns an inner-joined dataframe based on a given pair of columns.
    Equivalent to pandas isin(), but a faster vecotorized approach.
    '''
    df=df1.set_index(left_on).join(df2.set_index(right_on),how='inner',drop=drop)
    df=df.reset_index()
    df=df.rename(columns={'index':left_on})
    return df

def get_filtered_census():
    global year
    ark='ark'.format(year)
    if year=='1910':
        path1=r'R:\JoePriceResearch\record_linking\data\census_compact\1910\census1910.dta'.format(year)
        path2=r'R:\JoePriceResearch\record_linking\data\census_compact\1910\ark1910_hh.dta'.format(year)
        
        census=pd.read_stata(path1,columns=['index','household','rel'])
        ark_hh=pd.read_stata(path2)
        census.assign(ark1910=ark_hh['ark1910'])
        del ark_hh
        
        
    pids=pd.read_stata(r'R:\JoePriceResearch\record_linking\data\crosswalks\pid_ark{}.dta'.format(year))
    census=census.join(pids.set_index(ark), how='left', on=ark)
    del pids
    census=census[census['pid'].notnull()].drop(columns=[ark])
    master_hhid_list=get_master_hhid_list(census)
    census=census[census['household'].isin(master_hhid_list)]
    census=census.drop_duplicates(subset=['index'])
    return census
    
def find_kids(fam_df, target_index_list):
    '''
    target_index_list: list of target parent indexes
               fam_df: dataframe compact census containing everyone in household of target parents
                       columns needed: index, household, rel (relationship to head)
    
    Finds kids of parents given a list of parent indexes and a compact census dataframe containing 
    everyone in the households of said parents. The kids pids/indexes and parent indexes are then 
    appended to the master family dataframe.
    '''
    global df_fam_list
    kid_index_list=[]
    par_eligible=[]
    fam_index_df=pd.DataFrame(columns=['parent_pid','parent_index','children_pid'])
    fam_index_df['parent_index']=fam_df[fam_df['index'].isin(target_index_list)]['index']
    fam_index_df['parent_pid']=fam_df[fam_df['index'].isin(target_index_list)]['pid']
    
   
    if len(fam_index_df)>1:
        rel_list=fam_df[fam_df['index'].isin(target_index_list)]['rel'].tolist()
        
        if 0 in rel_list:
            par_eligible.append(fam_df[fam_df['rel'].isin([0,1])]['index'].tolist())
            kid_index_list.append(fam_df[fam_df['rel'].isin([2,3,17,25])]['index'].tolist())
        elif 1 in rel_list:
            par_eligible.append(fam_df[fam_df['rel'].isin([1])]['index'].tolist())
            kid_index_list.append(fam_df[fam_df['rel'].isin([2,3,17,25])]['index'].tolist())
        else:
            #case where target person(s) is parent of head
            #
            #
            # 7,15 = mother,father
            if (7 in rel_list) | (15 in rel_list):
                par_eligible.append(fam_df[fam_df['rel'].isin([7,15])]['index'].tolist())
                kid_index_list.append(fam_df[fam_df['rel'].isin([0,5,6])]['index'].tolist())
                
      
    par_eligible = [item for sublist in par_eligible for item in sublist]
    kid_index_list = [item for sublist in kid_index_list for item in sublist]
    
    #[str(i) for i in kid_index_list]
    if len(kid_index_list)>0:
        fam_index_df.loc[fam_index_df['parent_index'].isin(par_eligible),'children_pid']=\
        ','.join(fam_df[fam_df['index'].isin(kid_index_list)]['pid'].tolist())
    
    df_fam_list.append(fam_index_df)
        #%%

if __name__=='__main__':
    elderly_preproc()
    census=get_filtered_census()
    target_elderly=get_target_elderly()
    
    '''
    this code creates a dictionary that groups the target elderly indexes that share 
    the same household together. This helps more effectively match married couples
    to their children efficiently without repeated links.
    '''
    target_elderly['index']=target_elderly['index'].astype(str)
    target_elderly=(target_elderly.groupby('household')
                    .agg({ 'index' : ','.join})
                    .reset_index()
                    .reindex(columns=target_elderly.columns))
    print('8')
    target_elderly=target_elderly.to_dict('split')
    print('9')
    target_elderly=target_elderly['data']
    print('10')
    master_household_list=[item[1] for item in target_elderly]

   
    tic=time.time()
    df_fam_list=[]
    #len(master_household_list)
    for i in tqdm(range(0,len(master_household_list),k)):
        chunk_target_vars=target_elderly[i:i+k]
        chunk_hhid=master_household_list[i:i+k]
        chunk_df=census[census['household'].isin(chunk_hhid)]
        for list_ in chunk_target_vars:
            target_index_list=list(map(int,list_[0].split(',')))
            household=list_[1]
            
            fam_df=chunk_df[chunk_df['household']==household]
            
            find_kids(fam_df,target_index_list)
            
    print(time.time()-tic) 
    fam_master_table=pd.concat(df_fam_list,axis=0)
    
    fam_master_table=fam_master_table.dropna()
    fam_master_table.to_csv(r'R:\JoePriceResearch\record_linking\projects\social_security\data\parent_child_pids1920.csv',index=False)
    
    
    
    #%%
    fam_master_table=pd.read_csv(r'R:\JoePriceResearch\record_linking\projects\social_security\data\parent_child_pids1920')
    print('fff')
    pid_ark1940=pd.read_stata(r'R:\JoePriceResearch\record_linking\data\crosswalks\pid_ark1940.dta')
    trgt_pid_ark1940=pd.read_csv(r'R:\JoePriceResearch\record_linking\projects\social_security\data\target_pid_ark_crosswalk.csv')
    
    parent_pid=fam_master_table['parent_pid']
    fam_master_table = pd.DataFrame(fam_master_table['children_pid'].str.split(',').tolist(), index=fam_master_table['parent_index']).stack()
    fam_master_table = fam_master_table.reset_index()[[0, 'parent_index']]
    fam_master_table.columns=['pid','parent_index']
    
    fam_master_table=fam_master_table.merge(pid_ark1940,how='left',on='pid')
    fam_master_table=fam_master_table.dropna()   
    
    parents=pd.read_csv(r'R:\JoePriceResearch\record_linking\projects\social_security\target_index_1920.csv')
    parents=parents.rename(columns={'index1920':'parent_index'})
    fam_master_table=fam_master_table.merge(parents,how='left',on='parent_index')
    fam_master_table=fam_master_table.rename(columns={'ark1940':'child_ark','pid':'parent_pid'}).drop(columns=['ark1920','parent_index'])
    fam_master_table=fam_master_table.drop(columns=['parent_index'])
    fam_master_table.to_csv(r'R:\JoePriceResearch\record_linking\projects\social_security\data\parent_child_pids2.csv',index=False)
    
    fam_master_table['parent_pid'].nunique()
    ark_hh=pd.read_stata(r'R:\JoePriceResearch\record_linking\data\census_1940\ark1940_hh.dta')
    fam_master_table=fam_master_table.merge(pid_ark1940, how='left', left_on='parent_pid',right_on='pid').rename(columns={'ark1940':'parent_ark'})
    fam_master_table=fam_master_table.drop(columns=['pid'])
    fam_master_table.head()
    del pid_ark1940
    
    fam_master_table['parent_index'].nunique()
    fam_master_table=fam_master_table.merge(ark_hh, how='left',left_on='parent_ark',right_on='ark1940',left_index=True)
    fam_master_table=fam_master_table.merge(ark_hh, how='left',left_on='child_ark',right_on='ark1940',left_index=True).drop(columns='ark1940')

    fam_master_table=fam_master_table.rename(columns={'household1940':'child_hhid'})
    fam_master_table.head()
    
    fam_master_table['coresidence']=(fam_master_table['parent_hhid']==fam_master_table['child_hhid'])
    fam_master_table['coresidence'].value_counts()
    
   
    fs_anc=pd.read_csv(r'R:\JoePriceResearch\record_linking\data\crosswalks\familysearch_ancestry\ancestry_fsearch_1940.csv')
    fam_master_table=fam_master_table.merge(fs_anc,left_on='child_ark',right_on='ark1940',how='left')
    fam_master_table=fam_master_table.drop(columns=['ark1940']).rename(columns={'ancestry_id':'child_ancestry'})
    fam_master_table.columns.values
    fam_master_table=fam_master_table[['parent_ark','parent_pid', 'child_ark','child_pid', 'parent_ancestry','child_ancestry']]
    
    fam_master_table.iloc[12345:12355].to_csv(r'R:\JoePriceResearch\record_linking\projects\social_security\data\sample.csv',index=False)
    