# -*- coding: utf-8 -*-
"""
Created on Mon Feb 11 16:51:28 2019

@author: bbusath5
"""

import sys
import pandas as pd
from tqdm import tqdm
import requests
import session
sys.path.append('R:/JoePriceResearch/Python/all_code')
sys.path.append('R:\\JoePriceResearch\\Python\\Anaconda3\\Lib\\site-packages')
from FamilySearch1 import FamilySearch

#for _in in pd.read_csv(r'R:\JoePriceResearch\record_linking\projects\social_security\api_formatted_pids.csv'):
    
#_in.to_csv(r'R:\JoePriceResearch\record_linking\projects\social_security\in.csv',index=False)



#key='ccaecde6-f07f-4cb1-8b23-86215ad2f8c7-aws-prod '
test = FamilySearch('benbusath','1254Castlecombe.',r'R:\JoePriceResearch\record_linking\projects\social_security','in.csv','out.csv',auth=True)
#%%
with requests.Session() as session:
    info = session.get('http://api.familysearch.org/platform/tree/persons?pids=LVNM-RYXs')
#%%
persons = info.json()


for _in in tqdm(pd.read_csv(r'R:\JoePriceResearch\record_linking\projects\social_security\data\api_formatted.csv',chunksize=1000)):
    _in.to_csv(r'R:\JoePriceResearch\record_linking\projects\social_security\in.csv',index=False)
    
    sys.path.append(r'R:/JoePriceResearch/Python/all_code')
    test = FamilySearch('benbusath','1254Castlecombe.',r'R:\JoePriceResearch\record_linking\projects\social_security','in.csv','out.csv',auth=True)
    test.ScrapePerson()
    _out=pd.read_csv(r'R:\JoePriceResearch\record_linking\projects\social_security\out.csv')
    _out=_out[['FSID','kid_FSIDs']]
    _out=_out.rename(columns={'FSID':'pid','kid_FSIDs':'child_pids'})
    with open(r'R:\JoePriceResearch\record_linking\projects\social_security\parent_child_pids.csv','a') as master:
        _out.to_csv(master,index=False,header=False)

#C:\Users\bbusath5\AppData\Local\Continuum\anaconda3\python.exe R:\JoePriceResearch\record_linking\projects\social_security\ss_get_child_pids.py