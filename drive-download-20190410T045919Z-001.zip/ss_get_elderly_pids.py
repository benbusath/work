# -*- coding: utf-8 -*-
"""
Created on Fri Jan 18 12:26:23 2019

@author: bbusath5
"""

import pandas as pd
#import 1940 census data here


ark_1940=pd.read_stata(r'R:\JoePriceResearch\record_linking\data\census_1940\ark1940_1940_combined.dta').rename(columns={'_0':'ark1940'})  
birth_year=pd.read_stata(r'R:\JoePriceResearch\record_linking\data\census_1940\pr_age_1940_combined.dta').rename(columns={'_0':'age'})

ark_1940=ark_1940.assign(age=birth_year['pr_age']).drop(columns=['file'])
del birth_year
ark_1940.head()

ark_1940=ark_1940[(ark_1940['age']>=55)&(ark_1940['age']<=84)]
len(ark_1940)

pids=pd.read_stata(r'R:\JoePriceResearch\record_linking\data\crosswalks\pid_ark1940.dta')
target_pids=pids[pids['ark1940'].isin(ark_1940['ark1940'])]

target_pids.to_csv(r'R:\JoePriceResearch\record_linking\projects\social_security\data\elderly_pid_ark1940.csv',index=False)
#%%
target_pids.drop(columns='ark1940').rename(columns={'pid':'FSID'}).to_csv(r'R:\JoePriceResearch\record_linking\projects\social_security\in.csv',index_label='ID')
len(target_pids)


df=pd.read_csv(r'R:\JoePriceResearch\record_linking\projects\social_security\target_pid_ark_crosswalk.csv')
pids=pd.read_stata(r'R:\JoePriceResearch\record_linking\data\crosswalks\pid_ark1920.dta')

pids=pids[pids['pid'].isin(df['pid'])]
len(pids)
del df
int_ark=pd.read_stata(r'R\J:oePriceResearch\record_linking\data\census_compact\1920\int_ark1920.dta')
int_ark=int_ark.set_index('ark1920').join(pids.set_index('ark1920'),how='inner')
int_ark=int_ark.reset_index()
int_ark.to_csv(r'R:\JoePriceResearch\record_linking\projects\social_security\target_index_1920.csv',index=False)
